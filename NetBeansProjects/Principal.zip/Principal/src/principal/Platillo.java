
package principal;

public class Platillo {
 
    int cantidadplatillo;
    String tipoplatillo;

    public Platillo() {
    }
    public int getCantidadplatillo() {
        return cantidadplatillo;
    }

    public void setCantidadplatillo(int cantidadplatillo) {
        this.cantidadplatillo = cantidadplatillo;
    }

    public String getTipoplatillo() {
        return tipoplatillo;
    }

    public void setTipoplatillo(String tipoplatillo) {
        this.tipoplatillo = tipoplatillo;
    }
    
    
}
