
package principal;

public class Bebida {

int cantidadbebida;
String tipobebida;

    public Bebida() {
    }

    public int getCantidadbebida() {
        return cantidadbebida;
    }

    public void setCantidadbebida(int cantidadbebida) {
        this.cantidadbebida = cantidadbebida;
    }

    public String getTipobebida() {
        return tipobebida;
    }

    public void setTipobebida(String tipobebida) {
        this.tipobebida = tipobebida;
    }

}
