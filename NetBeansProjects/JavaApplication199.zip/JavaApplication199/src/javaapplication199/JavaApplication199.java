/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication199;

/**
 *
 * @author ASUS
 */
public class JavaApplication199 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
        System.out.println("¿QUE DIJISTE CORONÉ?");
        System.out.println("JAJAJAJAJAJAJAJA");
        System.out.println("No te pongas a estudiar");
    }
    
}
