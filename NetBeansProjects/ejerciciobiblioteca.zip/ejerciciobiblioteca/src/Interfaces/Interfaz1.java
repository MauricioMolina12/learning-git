/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

/**
 *
 * @author ASUS
 */
public interface Interfaz1 {
    
    public void entregar(String fecha);
    public void reservar(String fecha);
    
    
    
}
